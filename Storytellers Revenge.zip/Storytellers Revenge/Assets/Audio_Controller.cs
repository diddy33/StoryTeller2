﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Audio_Controller : MonoBehaviour {

    public GameObject PauseButton;
    public GameObject PlayButton;
    public AudioSource audioSource;
    private AudioClip _start_audio;

    //public AudioClip _playA_audio;
    // public AudioClip _playB_audio;
    //public AudioClip _start_audio;
    // public AudioClip _play_audio;
    //public AudioClip _exit_audio;

    //	private long _playA = 208;
    //	private long _playB = 375;
    //	private long _exit = 1337;  
    //	private long _start = 1;



    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        //audioSource.clip = _start_audio;
        //audioSource.Play();

        //		if(audioSource.clip !=null)
        //		{
        //			audioSource.EnableAudioTrack (0, true);
        //			audioSource.SetTargetAudioSource(0, audioSource);
        //			audioSource.clip = ;
        //		}
    }

    public void OnPauseButton()
    {
        audioSource.Pause();
    }

    public void OnPlayButton()
    {
        audioSource.Play();
    }

    
    }

    /*public void OnRestartButton()
    {
        audioSource.Stop();
        audioSource.clip = _start_audio;
        audioSource.Play();
    }

    public void OnExitButton()
    {
        audioSource.Stop(); audioSource.Play();
        audioSource.clip = _exit_audio;
        audioSource.Play();*/
    


