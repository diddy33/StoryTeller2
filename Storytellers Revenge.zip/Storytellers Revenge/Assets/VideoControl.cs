﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]

public class VideoControl : MonoBehaviour
{
   
    public GameObject pauseButton;
    public GameObject playButton;
    private UnityEngine.Video.VideoPlayer videoPlayer;
    public GameObject AudioSource;


    //[SerializeField]
    //private AudioSource audioSource;
    //private AudioClip NorwayButt;


    void Start()
    {
        videoPlayer = GetComponent<UnityEngine.Video.VideoPlayer>();
        //videoPlayer.Play();

//if (videoPlayer.clip != null)
        {
            GetComponent <AudioSource>();
            
           // videoPlayer.EnableAudioTrack(0, true);
            //videoPlayer.SetTargetAudioSource(0, audioSource);
        }
    }
    public void Pause()
    {
        videoPlayer.Pause();
        Debug.Log("Pause Pressed");
    }
    public void Play()
    {
        videoPlayer.Play();
        Debug.Log("Play Pressed");
    }

    public void PlayButtonPointerEnter()
    {
        Debug.Log("Play Button Entered");
    }
    public void PlayButtonPointerExit()
    {
        Debug.Log("Play Button Exited");
    }

    public void PauseButtonPointerEnter()
    {
        Debug.Log("Pause Button Entered");
    }
    public void PauseButtonPointerExit()
    {
        Debug.Log("Play Button Exited");
    }



    //Check if input keys have been pressed and call methods accordingly.
    /* void Update()
     {
         //Play or pause the video.
         if (Input.GetMouseButtonDown(0))

         {
             if (videoPlayer.isPlaying)
                 .Pause();
             else
                 videoPlayer.Play();
             audioSource.Play();



         }*/
}


