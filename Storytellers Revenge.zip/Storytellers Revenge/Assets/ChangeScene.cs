﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{


    public void GetActiveScene()
    {
        Debug.Log("My method was called");
        //SceneManager.LoadScene(sceneName);
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
    }

}